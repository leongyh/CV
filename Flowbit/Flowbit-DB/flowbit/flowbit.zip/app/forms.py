from flask.ext.wtf import Form, TextField, BooleanField, SelectField, HiddenField, PasswordField
from flask.ext.wtf import Required
from app import app

class LoginForm(Form):	
	username = TextField('username', validators = [Required()])
	password = PasswordField('password', validators = [Required()])
	remember_me = BooleanField('remember_me', default = False)
	
class RegistrationForm(Form):
	org_choices = []
	
	for orgs in app.config['ORGANIZATION_DBS']:
		org_choices.append((orgs['DBNAME'], orgs['DBALIAS']))

	
	username = TextField('username', validators = [Required()])
	password = PasswordField('password', validators = [Required()])
	password_repeat = PasswordField('password_repeat', validators = [Required()])
	firstName = TextField('firstName', validators = [Required()])
	lastName = TextField('lastName', validators = [Required()])
	email = TextField('email', validators = [Required()])
	organization = SelectField('organization', choices = org_choices, validators = [Required()])
	title = TextField('title', validators = [Required()]) #SelectField to hold better constraints?
	phone = TextField('phone', validators = [])
