from flask import render_template, flash, redirect, session, url_for, request, g
from flask.ext.login import login_user, logout_user, current_user, login_required

from app import app, lm, db_query, db_parse
from forms import LoginForm, RegistrationForm
from models import User

import json, urllib
from datetime import datetime

@lm.user_loader
def loadUser(username):
	if 'username' in session:
		db_parse.request('GET', '/1/users/' + str(username), '', {
			"X-Parse-Application-Id": app.config['PARSE_ID'],
			"X-Parse-REST-API-Key": app.config['PARSE_API_KEY']
		})
		return User(json.loads(db_parse.getresponse().read()))
	else:
		return None

@app.before_request
def before_request():
	g.user = None
	
	if 'username' in session:
		g.user = current_user

@app.route('/login', methods = ['GET', 'POST'])
def login():
	print('Login page\n')
	if g.user is not None and not g.user.is_anonymous():
		return redirect(url_for('index'))
	
	login_form = LoginForm()
	
	if login_form.validate_on_submit():
		print('Login page form submit\n')
		login_params = urllib.urlencode({"username": login_form.username.data, "password": login_form.password.data})
		db_parse.request('GET', '/1/login?%s' % login_params, '', {
			"X-Parse-Application-Id": app.config['PARSE_ID'],
			"X-Parse-REST-API-Key": app.config['PARSE_API_KEY']
		})
		
		session['remember_me'] = login_form.remember_me.data
		
		return registerOrLogin(json.loads(db_parse.getresponse().read()))
    
	return render_template('login.html', 
							title = 'Login',
							form = login_form)

def registerOrLogin(resp):
	print('Register or login\n')
	if 'code' in resp:
		if resp['code'] == 101:
			print('Redirect to register page\n') 
			return redirect(url_for('register'))
	
	session['username'] = resp['username']
	remember_me = False
	
	if 'remember_me' in session:
		remember_me = session['remember_me']
		session.pop('remember_me', None)
	
	login_user(User(resp), remember = remember_me)
	print('Logged in sucess\n')
	return redirect(request.args.get('next') or url_for('index'))
    
@app.route('/register', methods = ['GET', 'POST'])
def register():
	if g.user is not None and not g.user.is_anonymous():
		return redirect(url_for('index'))
	
	reg_form = RegistrationForm()
	
	if reg_form.validate_on_submit():
		print('Register form submit\n')
		if reg_form.password.data != reg_form.password_repeat.data:
			return redirect(url_for('register'))
		
		reg_params = json.dumps({
			"username": reg_form.username.data,
			"password": reg_form.password.data,
			"email": reg_form.email.data,
			"organization": reg_form.organization.data,
			"title": reg_form.title.data,
			"firstName": reg_form.firstName.data,
			"lastName": reg_form.lastName.data,
			"phone": reg_form.phone.data
		})
		
		db_parse.request('POST', '/1/users', reg_params, {
			"X-Parse-Application-Id": app.config['PARSE_ID'],
			"X-Parse-REST-API-Key": app.config['PARSE_API_KEY'],
			"Content-Type": "application/json"
		})
		
		db_parse.getresponse()
		
		login_params = urllib.urlencode({"username": reg_form.username.data, "password": reg_form.password.data})
		db_parse.request('GET', '/1/login?%s' % login_params, '', {
			"X-Parse-Application-Id": app.config['PARSE_ID'],
			"X-Parse-REST-API-Key": app.config['PARSE_API_KEY']
		})
		
		login_user(User(json.loads(db_parse.getresponse().read())), remember = remember_me)
		
		return redirect(url_for('index'))
		
	return render_template('register.html', title = 'Register', form = reg_form)

@app.route('/')
@app.route('/index')
@login_required
def index():
	
	
    return render_template('index.html',
        title = 'Home')

@app.route('/dashboard')
def dashboard():
	return render_template('dashboard.html',
        title = 'Dashboard')

@app.route('/charts')
def charts():
	return render_template('charts.html',
        title = 'Charts')

@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('login'))
