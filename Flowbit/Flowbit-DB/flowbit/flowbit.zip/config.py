import os

CSRF_ENABLED = True
SECRET_KEY = 'Flowbetches2012'

OPENID_PROVIDERS = [
    { 'name': 'Google', 'url': 'https://www.google.com/accounts/o8/id', 'imgsrc': '../static/img/openid/google-openid.png' },
    { 'name': 'Yahoo', 'url': 'https://me.yahoo.com', 'imgsrc': '../static/img/openid/yahoo-openid.png' }]

ORGANIZATION_DBS = [ 
	{ 'DBALIAS': 'Flowbit', 'DBNAME': 'Flowbit', 'HOST': '0.0.0.0', 'PORT': 27017 },
	{ 'DBALIAS': 'NuestraAgua', 'DBNAME': 'Nuestra Agua', 'HOST': '0.0.0.0', 'PORT': 27017 }]

ROLES = [ 'ADMIN', 'ENGINEER' ]
			
PARSE_ID = "7h8TXODIXq3dxx0yRk5TY1CRALyDcwjwdHYzLi7Q"
PARSE_API_KEY = "iy5G8coOQTsKlfqaGQgkN0f1cQnQyEtbLUN7PcuN"
			
basedir = os.path.abspath(os.path.dirname(__file__))